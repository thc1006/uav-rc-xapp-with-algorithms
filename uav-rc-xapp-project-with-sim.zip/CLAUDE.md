# CLAUDE.md — UAV RC xApp + Non-RT Planner + ns-O-RAN Sim

## What this repo is for

This repository is a **playground** for implementing O-RAN UAV use cases in a
RIC environment and exercising them in simulation (e.g., ns-O-RAN):

- **Use Case 2:** Flight Path Based Dynamic UAV Radio Resource Allocation.
- **Use Case 3:** Radio Resource Allocation for UAV Application Scenario.

Goals:

1. Define clean data models and algorithms for UAV-aware policies.
2. Implement a reusable Python package for the **Near-RT UAV policy**.
3. Implement a **Non-RT path planner** that outputs `FlightPlanPolicy`.
4. Provide a **simulation skeleton** (`sim/`) that connects planner,
   policy, and an ns-O-RAN-style topology.
5. Make the repo easy to extend via Claude Code (skills, subagents,
   commands).

## Repo layout

- `spec/uav_oran_usecase.md`
  - Textual O-RAN WG1 UAV use case description (user-provided).
- `docs/architecture.md`
  - Non-RT / Near-RT / RAN roles and assumptions.
- `docs/algorithms.md`
  - Path-aware + QoS-aware algorithm design for the Near-RT policy.
- `docs/sim-pipeline.md`
  - How Non-RT planner, Near-RT policy, and ns-O-RAN skeleton fit together.

- `xapps/uav-policy/`
  - `src/uav_policy/policy_engine.py` — Near-RT data models and algorithms.
  - `src/uav_policy/main.py` — simple CLI demo.
  - `tests/test_policy_engine.py` — unit tests (TDD entry point).

- `xapps/rc-grpc-client/`
  - `src/rc_grpc_client/client.py` — stub RC client (just logs decisions).

- `nonrt/uav-path-planner/`
  - `src/uav_path_planner/planner.py` — DP-based Non-RT path planner.
  - `src/uav_path_planner/main.py` — CLI demo (prints `FlightPlanPolicy` JSON).
  - `tests/test_planner.py` — unit tests for planner behavior.

- `sim/`
  - `nsoran/` — YAML skeleton for ns-O-RAN scenario + pipeline metadata.
  - `scripts/` — glue scripts that:
    - run the Non-RT planner,
    - run the Near-RT policy in a mock loop,
    - show how to hook into ns-O-RAN.
  - `artifacts/` — policies, decisions, logs (initially empty).

- `skills/` — Claude skills (digest use case, scaffold xApp, planner, sim).
- `subagents/` — RIC architect, xApp dev, sim integration, QA engineer.
- `commands/` — high-level Claude Code commands for stepwise work.

## Ground rules

1. **Respect O-RAN layering**
   - Non-RT planner: offline / long-timescale reasoning (flight path,
     radio maps, ML training).
   - Near-RT policy xApp: per-UAV, per-timeslot resource decisions.
   - RC xApp / RAN: actual E2SM_RC / vendor-specific control.

2. **Keep algorithms and transport separate**
   - `uav-policy` computes `ResourceDecision` objects only.
   - Transport to RC xApp (gRPC, REST, xApp descriptor/schema) belongs in
     `xapps/rc-grpc-client` or external repos.

3. **Prefer TDD**
   - For any new behavior:
     - Modify or add tests in `tests/`.
     - Then update code to satisfy tests.

4. **Make assumptions explicit**
   - When you assume a given KPM field, path accuracy, or RC capability,
     document it in `docs/` and/or comments.

## Claude Code workflow hints

- Use `/init-uav-rc-project` to start a session.
- Use `skills/uav-oran-usecase-digest` to refresh the WG1 UAV context.
- Use `skills/uav-policy-xapp-scaffolder` for Near-RT logic edits.
- Use `skills/uav-path-planner` to work on the Non-RT DP planner.
- Use `skills/sim-scenario-designer` or `skills/uav-sim-operator` to
  shape ns-O-RAN scenarios and integration.
