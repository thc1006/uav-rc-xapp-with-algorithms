# UAV Policy Algorithms for O-RAN RC Control (Near-RT)

This document summarizes the core Near-RT policy logic implemented in
`xapps/uav-policy/src/uav_policy/policy_engine.py`.

## Data model (Near-RT)

- `UavState`:
  - `uav_id`: UAV identifier.
  - `x, y, z`: current 3D position in a local coordinate system.
  - `slice_id`: optional business slice id.
  - `path_position`: optional scalar in `[0, 1]` representing UAV progress
    along its planned path.

- `RadioSnapshot`:
  - `serving_cell_id`
  - `neighbor_cell_ids` — ordered list by descending RSRP.
  - `rsrp_serving`
  - `rsrp_best_neighbor`
  - `prb_utilization_serving` — fraction in `[0, 1]`.
  - `prb_utilization_slice` — optional slice-level utilization.

- `PathSegmentPlan`:
  - `start_pos`, `end_pos` — path-position interval `[0, 1]`.
  - `planned_cell_id` — desired serving cell for this segment.
  - `slice_id` — desired slice.
  - `base_prb_quota` — baseline PRB quota (integer).

- `FlightPlanPolicy`:
  - `uav_id`
  - `segments: List[PathSegmentPlan]`

- `ServiceProfile`:
  - `name`
  - `target_bitrate_mbps`
  - `min_sinr_db`

- `ResourceDecision`:
  - `uav_id`
  - `target_cell_id`
  - `slice_id`
  - `prb_quota`
  - `reason`

## Online path-aware RC policy

`path_aware_rc_policy(...)` implements a path-aware + QoS-aware decision:

1. Determine the active path segment from `FlightPlanPolicy` and
   `UavState.path_position`.
2. Decide whether to keep the current serving cell or move to the segment's
   planned cell using:
   - serving cell load (`prb_utilization_serving`),
   - RSRP hysteresis between serving and best neighbor.
3. Choose a slice from `UavState` or the active segment.
4. Estimate a required PRB quota from a Shannon-like formula using a SINR
   proxy (serving or best-neighbor RSRP) and the `ServiceProfile` target
   bitrate.
5. Clamp PRB quota to a safe range and return a `ResourceDecision`.

A simpler `simple_path_aware_policy(...)` is also provided as a baseline.
