# Architecture Overview

We assume a standard O-RAN deployment:

- **Non-RT RIC / rApps**
  - Aggregate UAV flight paths, radio KPIs, and environment info.
  - Train path-aware models and derive `FlightPlanPolicy` objects.
  - Deliver policies to the Near-RT RIC (e.g., via A1 or other NBI).

- **Near-RT RIC / xApps**
  - `uav-policy` xApp:
    - Consumes `FlightPlanPolicy` per UAV (if available).
    - Consumes live E2SM_KPM measurements.
    - Produces `ResourceDecision`s per UAV.
  - RC xApp (not implemented here):
    - Receives high-level decisions (target cell / slice / PRB hints).
    - Maps them to E2SM_RC control actions.

- **RAN nodes (E2 nodes)**
  - CU-CP / CU-UP / DU / RU with E2 support.
  - Internal scheduler, beamformer, and HO logic remain vendor-specific;
    RC actions adjust configuration and weights.

This repository focuses on the **policy logic** at Non-RT and Near-RT,
with only a thin stub for RC integration and an ns-O-RAN simulation
skeleton under `sim/`.
