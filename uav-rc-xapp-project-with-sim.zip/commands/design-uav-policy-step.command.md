# Command: /design-uav-policy-step

## Purpose

Guide a small design + implementation step for the Near-RT UAV policy.

## Steps

1. Restate the requested behavior change or feature.
2. Identify affected structures/functions in `policy_engine.py`.
3. Update tests in `xapps/uav-policy/tests/test_policy_engine.py`.
4. Modify `xapps/uav-policy/src/uav_policy/policy_engine.py`.
5. Suggest a follow-up step (e.g., integration or new tests).
