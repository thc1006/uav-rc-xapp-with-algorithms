# Skill: UAV O-RAN Use-Case Digest

## Purpose

Use this skill to read and summarize the UAV-related O-RAN WG1 use cases
before modifying code.

## Instructions

1. Read `spec/uav_oran_usecase.md` carefully.
2. Extract:
   - Goals (KPIs to protect/improve).
   - Roles (Non-RT RIC, Near-RT RIC, Application servers, UAV, gNB/DU/RU).
   - Input data (flight path, radio KPIs, application QoS).
   - Output decisions (resource allocation hints, handover hints, slice use).
3. Write or update `docs/usecase_digest.md` (if present) with:
   - A high-level narrative.
   - A bullet list of policy requirements.
