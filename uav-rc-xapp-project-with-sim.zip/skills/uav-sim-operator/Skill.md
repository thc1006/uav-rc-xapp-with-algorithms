# Skill: UAV Simulation Operator

## Purpose

Use this skill to reason about simulation scenarios (ns-O-RAN, srsRAN+RIC,
etc.) and how to integrate the planner and policy with them.

## Instructions

1. Read:
   - `docs/architecture.md`
   - `docs/sim-pipeline.md`
   - `sim/README.md`
   - `sim/nsoran/*.yaml`
2. Propose or refine:
   - UAV flight paths and speeds.
   - Cell layouts and slice configurations.
   - Traffic profiles (video vs control).
3. For each scenario, specify:
   - Required KPM subscriptions.
   - Key metrics to log (HO count, throughput, latency, impact on ground UEs).
   - How `ResourceDecision`s will be translated into RC actions.
