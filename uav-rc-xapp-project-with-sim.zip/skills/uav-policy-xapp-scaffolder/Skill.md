# Skill: UAV Policy xApp Scaffolder

## Purpose

Use this skill to add or modify behavior in `xapps/uav-policy`.

## Instructions

1. Read:
   - `CLAUDE.md`
   - `docs/algorithms.md`
   - `xapps/uav-policy/README.md`
2. When changing behavior:
   - First update or add tests in `xapps/uav-policy/tests/test_policy_engine.py`.
   - Then modify `xapps/uav-policy/src/uav_policy/policy_engine.py`.
3. Keep functions:
   - Pure (no network I/O).
   - Small and well-documented.
4. Update `docs/algorithms.md` when adding significant logic.
