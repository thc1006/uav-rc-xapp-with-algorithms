# rc-grpc-client

This package is a stub for a client that would send `ResourceDecision`s
to an RC xApp over gRPC (or another IPC mechanism).

- In this skeleton, it only prints decisions to stdout.
- In a real deployment, you would:
  - Import gRPC stubs generated from the RC xApp's `.proto` files.
  - Map fields from `ResourceDecision` into those messages.
