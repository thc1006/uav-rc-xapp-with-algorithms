# uav-policy xApp (Near-RT)

This package contains the **policy engine** for UAV-related O-RAN use cases.

Key files:

- `src/uav_policy/policy_engine.py` — data models and algorithms.
- `src/uav_policy/main.py` — simple CLI demo.
- `tests/test_policy_engine.py` — unit tests.
